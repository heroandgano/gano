package p;

import java.sql.*;
import java.util.*;

public class CustomerDAO extends MadangDAO{
	
	public CustomerDAO() {
		super();
	}
	
	public List<Customer> select() {
		List<Customer> rtn = new ArrayList<>();

		String sql = "SELECT id, name, address, phone FROM customer";
		try (Connection c = dataSource.getConnection();
				PreparedStatement ps = c.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();) {
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getInt("id"));
				customer.setName(rs.getString("name"));
				customer.setAddress(rs.getString("address"));
				customer.setPhone(rs.getString("phone"));
				rtn.add(customer);
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}

		return rtn;
	}
	
	public Customer selectById(int id) {
		Customer rtn = null;

		String sql = "SELECT id, name, address, phone FROM customer WHERE id = ?";
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setInt(1, id);
			try (ResultSet rs = ps.executeQuery();) {
				if (rs.next()) {
					rtn = new Customer();
					rtn.setId(rs.getInt("id"));
					rtn.setName(rs.getString("name"));
					rtn.setAddress(rs.getString("address"));
					rtn.setPhone(rs.getString("phone"));
				}
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}

		return rtn;
	}
	
	public void insert(Customer customer) {
		String sql = "INSERT INTO customer (name, address, phone) VALUES (?,?,?)";
		
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setString(1, customer.getName());
			ps.setString(2, customer.getAddress());
			ps.setString(3, customer.getPhone());
			ps.executeUpdate();
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void update(Customer customer) {
		String sql = "UPDATE customer SET name = ?, address = ?, phone = ? WHERE id = ?";
		
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setString(1, customer.getName());
			ps.setString(2, customer.getAddress());
			ps.setString(3, customer.getPhone());
			ps.setInt(4, customer.getId());
			ps.executeUpdate();
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void delete(int id) {
		String sql = "DELETE FROM customer WHERE id = ?";
		
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}
}
