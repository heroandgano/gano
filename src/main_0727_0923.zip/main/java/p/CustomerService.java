package p;

import java.util.List;

public class CustomerService {
	CustomerDAO customerDao;

	public CustomerService() {
		customerDao = new CustomerDAO();
	}

	public List<Customer> get() {
		return customerDao.select();
	}

	public Customer getOrBlank(int id) {
		Customer rtn = null;

		rtn = customerDao.selectById(id);

		if (rtn == null) {
			rtn = new Customer();
			rtn.setId(-1);
			rtn.setName("");
			rtn.setAddress("");
			rtn.setPhone("");
		}

		return rtn;
	}
	
	public void add(Customer customer) {
		customerDao.insert(customer);
	}
	
	public void set(Customer customer) {
		customerDao.update(customer);
	}
	
	public void remove(int id) {
		customerDao.delete(id);
	}
}
