package p;

import java.sql.*;
import java.util.*;

public class BookDAO extends MadangDAO{
	
	public BookDAO() {
		super();
	}
	
	public List<Book> select() {
		List<Book> rtn = new ArrayList<>();

		String sql = "SELECT id, title, publisher, price FROM book";
		try (Connection c = dataSource.getConnection();
				PreparedStatement ps = c.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();) {
			while (rs.next()) {
				Book book = new Book();
				book.setId(rs.getInt("id"));
				book.setTitle(rs.getString("title"));
				book.setPublisher(rs.getString("publisher"));
				book.setPrice(rs.getInt("price"));
				rtn.add(book);
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}

		return rtn;
	}

	public Book selectById(int id) {
		Book rtn = null;

		String sql = "SELECT id, title, publisher, price FROM book WHERE id = ?";
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setInt(1, id);
			try (ResultSet rs = ps.executeQuery();) {
				if (rs.next()) {
					rtn = new Book();
					rtn.setId(rs.getInt("id"));
					rtn.setTitle(rs.getString("title"));
					rtn.setPublisher(rs.getString("publisher"));
					rtn.setPrice(rs.getInt("price"));
				}
			}

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}

		return rtn;
	}
	
	
	public void insert(Book book) {
		String sql = "INSERT INTO book (title, publisher, price) VALUES (?,?,?)";
		
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setString(1, book.getTitle());
			ps.setString(2, book.getPublisher());
			ps.setInt(3, book.getPrice());
			ps.executeUpdate();
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void update(Book book) {
		String sql = "UPDATE book SET title = ?, publisher = ?, price = ? WHERE id = ?";
		
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setString(1, book.getTitle());
			ps.setString(2, book.getPublisher());
			ps.setInt(3, book.getPrice());
			ps.setInt(4, book.getId());
			ps.executeUpdate();
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	public void delete(int id) {
		String sql = "DELETE FROM book WHERE id = ?";
		
		try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch(SQLException sqle) {
			sqle.printStackTrace();
		}
	}
}
